exports.add = function(a,b){
    return a + b
}

exports.sub = function(a,b){
    return a - b
}

var x = 200 // not exported
exports.name = "Siddhant"