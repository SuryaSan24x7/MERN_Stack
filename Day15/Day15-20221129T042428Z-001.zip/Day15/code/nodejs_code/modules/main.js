var calc = require("./calculator")

console.log(calc.add(10,20))
console.log(calc.sub(20,30))
console.log(calc.name)